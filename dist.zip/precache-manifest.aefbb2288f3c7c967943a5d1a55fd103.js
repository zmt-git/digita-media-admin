self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d798b6bd74caa22115c4f5dd0d8f7337",
    "url": "config.js"
  },
  {
    "revision": "fa0460ed337b8a4dc0280a9db9b322c2",
    "url": "css/pageLoading.css"
  },
  {
    "revision": "660de58b655914e60dd9e4e0fb408663",
    "url": "index.html"
  },
  {
    "revision": "e7b2d95bee09b90a15998827e4f62cb2",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "e975e20e5f4eb014f934",
    "url": "static/css/app.153c725e.css"
  },
  {
    "revision": "0abbb8c767044a8cea8b",
    "url": "static/css/chunk-elementUI.caa671fd.css"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/css/chunk-libs.a7a1f4ed.css"
  },
  {
    "revision": "366087f32730a544c3a3",
    "url": "static/css/route-deviceAdd.332e44b1.css"
  },
  {
    "revision": "da0c1cfbe2206ddcd312",
    "url": "static/css/route-deviceDetail.662deb95.css"
  },
  {
    "revision": "4f650b103ed7e255a82b",
    "url": "static/css/route-index.b085d24d.css"
  },
  {
    "revision": "c54a2337872b2d00cdf5",
    "url": "static/css/route-login.174db39c.css"
  },
  {
    "revision": "5c0fb9510bff778a14b4",
    "url": "static/css/route-mediaDetail.cbbc6f31.css"
  },
  {
    "revision": "5768176f50a4fb6a5fe1",
    "url": "static/css/route-mediaList.bb219e8b.css"
  },
  {
    "revision": "317b7ec6f39ab70fc02c",
    "url": "static/css/route-register.a040e5cc.css"
  },
  {
    "revision": "af12ff26ce6ec4a2adf1",
    "url": "static/css/route-server.6e9deedf.css"
  },
  {
    "revision": "676a556662e257e37f13",
    "url": "static/css/route-suggestAdd.0e02be5a.css"
  },
  {
    "revision": "0b64f28b2bba9576e1f3",
    "url": "static/css/route-taskList.cd4baab0.css"
  },
  {
    "revision": "a8853b434a09cbb5fd2b",
    "url": "static/css/route-userAgreement.772076c8.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "static/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "static/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "9865378e097d8e0c810680e2270f5bbb",
    "url": "static/fonts/iconfont.9865378e.ttf"
  },
  {
    "revision": "c66a28c69758311200c5e67531f48858",
    "url": "static/fonts/iconfont.c66a28c6.woff"
  },
  {
    "revision": "d51d021f9f72b6624cf810f492a3ed27",
    "url": "static/fonts/iconfont.d51d021f.woff2"
  },
  {
    "revision": "cce364ca9841162e3706e4f2ce0236fd",
    "url": "static/img/bg.cce364ca.webp"
  },
  {
    "revision": "6ef573dc47088fc3cb1dc910dc86a328",
    "url": "static/img/customizeScenes.6ef573dc.jpg"
  },
  {
    "revision": "f23600fbafed90f105cddbcffe2345bb",
    "url": "static/img/device.f23600fb.png"
  },
  {
    "revision": "ac85c0da7410da0a7bb5e9742491cf9e",
    "url": "static/img/empty.ac85c0da.png"
  },
  {
    "revision": "2b3728baadaf14637bc92205cfeb1f53",
    "url": "static/img/form_bg.2b3728ba.webp"
  },
  {
    "revision": "7c73e63cf036cf6aa89f9bdd2a34d8e8",
    "url": "static/img/lightScenes.7c73e63c.jpg"
  },
  {
    "revision": "bf608a126499dd90e226aa63cbc9050b",
    "url": "static/img/logo.bf608a12.png"
  },
  {
    "revision": "3809f74025db8b6a7c249e0f492597c4",
    "url": "static/img/orient.3809f740.jpg"
  },
  {
    "revision": "ec0e48cca9caf1df73018d81a3ae5c7c",
    "url": "static/img/roadScenes.ec0e48cc.jpg"
  },
  {
    "revision": "3f96a5c91876ac87ed1ef0de6691f3a6",
    "url": "static/img/weatherScenes.3f96a5c9.jpg"
  },
  {
    "revision": "e975e20e5f4eb014f934",
    "url": "static/js/app.a3d26bff.js"
  },
  {
    "revision": "0abbb8c767044a8cea8b",
    "url": "static/js/chunk-elementUI.b8932a6a.js"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/js/chunk-libs.309eb008.js"
  },
  {
    "revision": "366087f32730a544c3a3",
    "url": "static/js/route-deviceAdd.7e167d90.js"
  },
  {
    "revision": "da0c1cfbe2206ddcd312",
    "url": "static/js/route-deviceDetail.f898493f.js"
  },
  {
    "revision": "4f650b103ed7e255a82b",
    "url": "static/js/route-index.e10be5f9.js"
  },
  {
    "revision": "c54a2337872b2d00cdf5",
    "url": "static/js/route-login.daf0bda3.js"
  },
  {
    "revision": "5c0fb9510bff778a14b4",
    "url": "static/js/route-mediaDetail.b6bd7c83.js"
  },
  {
    "revision": "5768176f50a4fb6a5fe1",
    "url": "static/js/route-mediaList.539dbc0b.js"
  },
  {
    "revision": "317b7ec6f39ab70fc02c",
    "url": "static/js/route-register.829aff23.js"
  },
  {
    "revision": "af12ff26ce6ec4a2adf1",
    "url": "static/js/route-server.1ee63ee1.js"
  },
  {
    "revision": "e8b05dd7c87e2ebc6091",
    "url": "static/js/route-suggest.38cd8812.js"
  },
  {
    "revision": "676a556662e257e37f13",
    "url": "static/js/route-suggestAdd.a1ff2fb6.js"
  },
  {
    "revision": "0b64f28b2bba9576e1f3",
    "url": "static/js/route-taskList.98308b93.js"
  },
  {
    "revision": "ad02a46bd62deac8cc01",
    "url": "static/js/route-user.ae8997f4.js"
  },
  {
    "revision": "a8853b434a09cbb5fd2b",
    "url": "static/js/route-userAgreement.89a1cc96.js"
  },
  {
    "revision": "4270b477791ec77a4e62",
    "url": "static/js/runtime.354381e2.js"
  },
  {
    "revision": "310eb5526318b24f38e9",
    "url": "static/js/vendors~route-deviceDetail.f5e18d00.js"
  },
  {
    "revision": "2f682a53fb14dd6b3ba9",
    "url": "static/js/vendors~route-deviceDetail~route-mediaDetail~route-mediaList.3f78c8c9.js"
  },
  {
    "revision": "3cb25454b2f6c9039db1",
    "url": "static/js/vendors~route-register.9035bb88.js"
  }
]);