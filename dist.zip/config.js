window.globalConfig = {
  api_url: 'http://47.114.6.168:8080',
  ws_url: 'ws://47.114.6.168:8080/websocket/android/'
  // api_url: 'http://39.100.241.240:11000',
  // ws_url: 'ws://39.100.241.240/websocket/android/'
}
