self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d798b6bd74caa22115c4f5dd0d8f7337",
    "url": "config.js"
  },
  {
    "revision": "fa0460ed337b8a4dc0280a9db9b322c2",
    "url": "css/pageLoading.css"
  },
  {
    "revision": "a384a03077586340f217c6bf7502029c",
    "url": "index.html"
  },
  {
    "revision": "e7b2d95bee09b90a15998827e4f62cb2",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "f3ad6f106b2960baebd6",
    "url": "static/css/app.b4651ad8.css"
  },
  {
    "revision": "5441668116cc81b7a884",
    "url": "static/css/chunk-elementUI.caa671fd.css"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/css/chunk-libs.a7a1f4ed.css"
  },
  {
    "revision": "d099d911ee2331d67383",
    "url": "static/css/route-deviceAdd.60c25a28.css"
  },
  {
    "revision": "8cabb6ff5bf088b4538c",
    "url": "static/css/route-deviceDetail.0da47306.css"
  },
  {
    "revision": "7eea0d0f595626b717e2",
    "url": "static/css/route-index.a73ede52.css"
  },
  {
    "revision": "56fc3c27b09489698ab6",
    "url": "static/css/route-login.0b0006f6.css"
  },
  {
    "revision": "232ec6fb905d92fcc64c",
    "url": "static/css/route-mediaDetail.cbbc6f31.css"
  },
  {
    "revision": "351dba719ff4dc920781",
    "url": "static/css/route-mediaList.07252bdd.css"
  },
  {
    "revision": "adb2fc30d08e670d6b86",
    "url": "static/css/route-register.a040e5cc.css"
  },
  {
    "revision": "1c65a15512a93725a796",
    "url": "static/css/route-server.6e9deedf.css"
  },
  {
    "revision": "618ad3a1669ceab29337",
    "url": "static/css/route-suggestAdd.99b05894.css"
  },
  {
    "revision": "d61b8024f0d57b70b9f5",
    "url": "static/css/route-taskList.cd4baab0.css"
  },
  {
    "revision": "40284f057b55c645b308",
    "url": "static/css/route-userAgreement.772076c8.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "static/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "static/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "9865378e097d8e0c810680e2270f5bbb",
    "url": "static/fonts/iconfont.9865378e.ttf"
  },
  {
    "revision": "c66a28c69758311200c5e67531f48858",
    "url": "static/fonts/iconfont.c66a28c6.woff"
  },
  {
    "revision": "d51d021f9f72b6624cf810f492a3ed27",
    "url": "static/fonts/iconfont.d51d021f.woff2"
  },
  {
    "revision": "cce364ca9841162e3706e4f2ce0236fd",
    "url": "static/img/bg.cce364ca.webp"
  },
  {
    "revision": "6ef573dc47088fc3cb1dc910dc86a328",
    "url": "static/img/customizeScenes.6ef573dc.jpg"
  },
  {
    "revision": "f23600fbafed90f105cddbcffe2345bb",
    "url": "static/img/device.f23600fb.png"
  },
  {
    "revision": "ac85c0da7410da0a7bb5e9742491cf9e",
    "url": "static/img/empty.ac85c0da.png"
  },
  {
    "revision": "2b3728baadaf14637bc92205cfeb1f53",
    "url": "static/img/form_bg.2b3728ba.webp"
  },
  {
    "revision": "7c73e63cf036cf6aa89f9bdd2a34d8e8",
    "url": "static/img/lightScenes.7c73e63c.jpg"
  },
  {
    "revision": "bf608a126499dd90e226aa63cbc9050b",
    "url": "static/img/logo.bf608a12.png"
  },
  {
    "revision": "11c2005ca0ab40fd8a2d9074874755a2",
    "url": "static/img/orient.11c2005c.png"
  },
  {
    "revision": "ec0e48cca9caf1df73018d81a3ae5c7c",
    "url": "static/img/roadScenes.ec0e48cc.jpg"
  },
  {
    "revision": "3f96a5c91876ac87ed1ef0de6691f3a6",
    "url": "static/img/weatherScenes.3f96a5c9.jpg"
  },
  {
    "revision": "f3ad6f106b2960baebd6",
    "url": "static/js/app.811da1ad.js"
  },
  {
    "revision": "5441668116cc81b7a884",
    "url": "static/js/chunk-elementUI.fce3879b.js"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/js/chunk-libs.309eb008.js"
  },
  {
    "revision": "d099d911ee2331d67383",
    "url": "static/js/route-deviceAdd.5aa30ed7.js"
  },
  {
    "revision": "8cabb6ff5bf088b4538c",
    "url": "static/js/route-deviceDetail.9bfe5bbd.js"
  },
  {
    "revision": "7eea0d0f595626b717e2",
    "url": "static/js/route-index.521b88b0.js"
  },
  {
    "revision": "56fc3c27b09489698ab6",
    "url": "static/js/route-login.2543f58d.js"
  },
  {
    "revision": "232ec6fb905d92fcc64c",
    "url": "static/js/route-mediaDetail.3ecc6497.js"
  },
  {
    "revision": "351dba719ff4dc920781",
    "url": "static/js/route-mediaList.dba937d1.js"
  },
  {
    "revision": "adb2fc30d08e670d6b86",
    "url": "static/js/route-register.9173dc21.js"
  },
  {
    "revision": "1c65a15512a93725a796",
    "url": "static/js/route-server.d456c232.js"
  },
  {
    "revision": "9f2adaf99585b2a9dd9d",
    "url": "static/js/route-suggest.2878450e.js"
  },
  {
    "revision": "618ad3a1669ceab29337",
    "url": "static/js/route-suggestAdd.17115e81.js"
  },
  {
    "revision": "d61b8024f0d57b70b9f5",
    "url": "static/js/route-taskList.4d2619dc.js"
  },
  {
    "revision": "f72f518b9f472f50feb4",
    "url": "static/js/route-user.a85350a3.js"
  },
  {
    "revision": "40284f057b55c645b308",
    "url": "static/js/route-userAgreement.503b0590.js"
  },
  {
    "revision": "09c9855d47927fb748a0",
    "url": "static/js/runtime.d4d6085d.js"
  },
  {
    "revision": "310eb5526318b24f38e9",
    "url": "static/js/vendors~route-deviceDetail.f5e18d00.js"
  },
  {
    "revision": "2f682a53fb14dd6b3ba9",
    "url": "static/js/vendors~route-deviceDetail~route-mediaDetail~route-mediaList.3f78c8c9.js"
  },
  {
    "revision": "3cb25454b2f6c9039db1",
    "url": "static/js/vendors~route-register.9035bb88.js"
  }
]);