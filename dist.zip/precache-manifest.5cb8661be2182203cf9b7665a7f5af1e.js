self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d798b6bd74caa22115c4f5dd0d8f7337",
    "url": "config.js"
  },
  {
    "revision": "fa0460ed337b8a4dc0280a9db9b322c2",
    "url": "css/pageLoading.css"
  },
  {
    "revision": "296f2cb0fbfca211c47a4fde514add7d",
    "url": "index.html"
  },
  {
    "revision": "e7b2d95bee09b90a15998827e4f62cb2",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "63c766da9d6f55d58f0b",
    "url": "static/css/app.e947a5f1.css"
  },
  {
    "revision": "0abbb8c767044a8cea8b",
    "url": "static/css/chunk-elementUI.caa671fd.css"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/css/chunk-libs.a7a1f4ed.css"
  },
  {
    "revision": "60c995d83bb588a1e116",
    "url": "static/css/route-deviceAdd.248cc9c9.css"
  },
  {
    "revision": "e67dc409a0c2b02779ec",
    "url": "static/css/route-deviceDetail.c347e585.css"
  },
  {
    "revision": "b8d5932b7d6595f047bc",
    "url": "static/css/route-index.b085d24d.css"
  },
  {
    "revision": "fd45fee47f4f6bbb58b5",
    "url": "static/css/route-login.88a4e824.css"
  },
  {
    "revision": "bbf352bbaa3c18ba0a9b",
    "url": "static/css/route-mediaDetail.cbbc6f31.css"
  },
  {
    "revision": "db7ac657a890bc963d44",
    "url": "static/css/route-mediaList.cefe8a62.css"
  },
  {
    "revision": "9f5fd57cacede988b190",
    "url": "static/css/route-register.ce20e1f1.css"
  },
  {
    "revision": "8a08e34aa4e64063b549",
    "url": "static/css/route-server.144f7d5f.css"
  },
  {
    "revision": "c1bdfb5d65c1d4df3397",
    "url": "static/css/route-suggestAdd.e76ea83d.css"
  },
  {
    "revision": "0a6fc1313d0cc64ec9f7",
    "url": "static/css/route-taskList.56d82622.css"
  },
  {
    "revision": "6d7f2217734d18798315",
    "url": "static/css/route-userAgreement.772076c8.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "static/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "static/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "9865378e097d8e0c810680e2270f5bbb",
    "url": "static/fonts/iconfont.9865378e.ttf"
  },
  {
    "revision": "c66a28c69758311200c5e67531f48858",
    "url": "static/fonts/iconfont.c66a28c6.woff"
  },
  {
    "revision": "d51d021f9f72b6624cf810f492a3ed27",
    "url": "static/fonts/iconfont.d51d021f.woff2"
  },
  {
    "revision": "cce364ca9841162e3706e4f2ce0236fd",
    "url": "static/img/bg.cce364ca.webp"
  },
  {
    "revision": "6ef573dc47088fc3cb1dc910dc86a328",
    "url": "static/img/customizeScenes.6ef573dc.jpg"
  },
  {
    "revision": "f23600fbafed90f105cddbcffe2345bb",
    "url": "static/img/device.f23600fb.png"
  },
  {
    "revision": "ac85c0da7410da0a7bb5e9742491cf9e",
    "url": "static/img/empty.ac85c0da.png"
  },
  {
    "revision": "2b3728baadaf14637bc92205cfeb1f53",
    "url": "static/img/form_bg.2b3728ba.webp"
  },
  {
    "revision": "7c73e63cf036cf6aa89f9bdd2a34d8e8",
    "url": "static/img/lightScenes.7c73e63c.jpg"
  },
  {
    "revision": "bf608a126499dd90e226aa63cbc9050b",
    "url": "static/img/logo.bf608a12.png"
  },
  {
    "revision": "3809f74025db8b6a7c249e0f492597c4",
    "url": "static/img/orient.3809f740.jpg"
  },
  {
    "revision": "ec0e48cca9caf1df73018d81a3ae5c7c",
    "url": "static/img/roadScenes.ec0e48cc.jpg"
  },
  {
    "revision": "3f96a5c91876ac87ed1ef0de6691f3a6",
    "url": "static/img/weatherScenes.3f96a5c9.jpg"
  },
  {
    "revision": "63c766da9d6f55d58f0b",
    "url": "static/js/app.6faf29b1.js"
  },
  {
    "revision": "0abbb8c767044a8cea8b",
    "url": "static/js/chunk-elementUI.b8932a6a.js"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/js/chunk-libs.309eb008.js"
  },
  {
    "revision": "60c995d83bb588a1e116",
    "url": "static/js/route-deviceAdd.4d862d8f.js"
  },
  {
    "revision": "e67dc409a0c2b02779ec",
    "url": "static/js/route-deviceDetail.3626faaf.js"
  },
  {
    "revision": "b8d5932b7d6595f047bc",
    "url": "static/js/route-index.7cb1a8dc.js"
  },
  {
    "revision": "fd45fee47f4f6bbb58b5",
    "url": "static/js/route-login.46347a83.js"
  },
  {
    "revision": "bbf352bbaa3c18ba0a9b",
    "url": "static/js/route-mediaDetail.2533f67c.js"
  },
  {
    "revision": "db7ac657a890bc963d44",
    "url": "static/js/route-mediaList.e49e511b.js"
  },
  {
    "revision": "9f5fd57cacede988b190",
    "url": "static/js/route-register.2616bb70.js"
  },
  {
    "revision": "8a08e34aa4e64063b549",
    "url": "static/js/route-server.f331a69b.js"
  },
  {
    "revision": "054fe910eff5ef7a1a99",
    "url": "static/js/route-suggest.8fb2b00f.js"
  },
  {
    "revision": "c1bdfb5d65c1d4df3397",
    "url": "static/js/route-suggestAdd.bcfe884b.js"
  },
  {
    "revision": "0a6fc1313d0cc64ec9f7",
    "url": "static/js/route-taskList.b417ad3d.js"
  },
  {
    "revision": "b5c3f04b7f293b2fbe14",
    "url": "static/js/route-user.00d5d09d.js"
  },
  {
    "revision": "6d7f2217734d18798315",
    "url": "static/js/route-userAgreement.542eafe0.js"
  },
  {
    "revision": "581c4ba891428b73ee38",
    "url": "static/js/runtime.60d2e4bc.js"
  },
  {
    "revision": "310eb5526318b24f38e9",
    "url": "static/js/vendors~route-deviceDetail.f5e18d00.js"
  },
  {
    "revision": "2f682a53fb14dd6b3ba9",
    "url": "static/js/vendors~route-deviceDetail~route-mediaDetail~route-mediaList.3f78c8c9.js"
  },
  {
    "revision": "a23b65a5eecb7772dabf",
    "url": "static/js/vendors~route-mediaList.5e5c793a.js"
  },
  {
    "revision": "3cb25454b2f6c9039db1",
    "url": "static/js/vendors~route-register.9035bb88.js"
  }
]);