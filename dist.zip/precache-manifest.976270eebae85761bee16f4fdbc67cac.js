self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d798b6bd74caa22115c4f5dd0d8f7337",
    "url": "config.js"
  },
  {
    "revision": "fa0460ed337b8a4dc0280a9db9b322c2",
    "url": "css/pageLoading.css"
  },
  {
    "revision": "1c6f5ff7aec008e8a5cb7facce146f1a",
    "url": "index.html"
  },
  {
    "revision": "e7b2d95bee09b90a15998827e4f62cb2",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "d567efc626fd47e91eea",
    "url": "static/css/app.e947a5f1.css"
  },
  {
    "revision": "0abbb8c767044a8cea8b",
    "url": "static/css/chunk-elementUI.caa671fd.css"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/css/chunk-libs.a7a1f4ed.css"
  },
  {
    "revision": "3b1146e16294dce29ad1",
    "url": "static/css/route-deviceAdd.248cc9c9.css"
  },
  {
    "revision": "689fed1e568c832cc989",
    "url": "static/css/route-deviceDetail.9e60ed7b.css"
  },
  {
    "revision": "af7c5b092f32991ea4f9",
    "url": "static/css/route-index.f7ed0d2b.css"
  },
  {
    "revision": "c0ae79fcfa2f087e9fbb",
    "url": "static/css/route-login.88a4e824.css"
  },
  {
    "revision": "434a03c152db4eefe679",
    "url": "static/css/route-mediaDetail.cbbc6f31.css"
  },
  {
    "revision": "716dec28ef8d2f3f53e3",
    "url": "static/css/route-mediaList.cefe8a62.css"
  },
  {
    "revision": "4f5dafce39a110e16334",
    "url": "static/css/route-register.ce20e1f1.css"
  },
  {
    "revision": "432cfda7fb9c9bb05ac2",
    "url": "static/css/route-server.144f7d5f.css"
  },
  {
    "revision": "dc54d771e3d5a37fcf9e",
    "url": "static/css/route-suggestAdd.e76ea83d.css"
  },
  {
    "revision": "4eea055d84f177c23f4e",
    "url": "static/css/route-taskList.56d82622.css"
  },
  {
    "revision": "40cff8e59a35326da1ed",
    "url": "static/css/route-userAgreement.772076c8.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "static/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "static/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "9865378e097d8e0c810680e2270f5bbb",
    "url": "static/fonts/iconfont.9865378e.ttf"
  },
  {
    "revision": "c66a28c69758311200c5e67531f48858",
    "url": "static/fonts/iconfont.c66a28c6.woff"
  },
  {
    "revision": "d51d021f9f72b6624cf810f492a3ed27",
    "url": "static/fonts/iconfont.d51d021f.woff2"
  },
  {
    "revision": "cce364ca9841162e3706e4f2ce0236fd",
    "url": "static/img/bg.cce364ca.webp"
  },
  {
    "revision": "6ef573dc47088fc3cb1dc910dc86a328",
    "url": "static/img/customizeScenes.6ef573dc.jpg"
  },
  {
    "revision": "f23600fbafed90f105cddbcffe2345bb",
    "url": "static/img/device.f23600fb.png"
  },
  {
    "revision": "ac85c0da7410da0a7bb5e9742491cf9e",
    "url": "static/img/empty.ac85c0da.png"
  },
  {
    "revision": "2b3728baadaf14637bc92205cfeb1f53",
    "url": "static/img/form_bg.2b3728ba.webp"
  },
  {
    "revision": "7c73e63cf036cf6aa89f9bdd2a34d8e8",
    "url": "static/img/lightScenes.7c73e63c.jpg"
  },
  {
    "revision": "bf608a126499dd90e226aa63cbc9050b",
    "url": "static/img/logo.bf608a12.png"
  },
  {
    "revision": "3809f74025db8b6a7c249e0f492597c4",
    "url": "static/img/orient.3809f740.jpg"
  },
  {
    "revision": "ec0e48cca9caf1df73018d81a3ae5c7c",
    "url": "static/img/roadScenes.ec0e48cc.jpg"
  },
  {
    "revision": "3f96a5c91876ac87ed1ef0de6691f3a6",
    "url": "static/img/weatherScenes.3f96a5c9.jpg"
  },
  {
    "revision": "d567efc626fd47e91eea",
    "url": "static/js/app.fb8c3e36.js"
  },
  {
    "revision": "0abbb8c767044a8cea8b",
    "url": "static/js/chunk-elementUI.b8932a6a.js"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/js/chunk-libs.309eb008.js"
  },
  {
    "revision": "3b1146e16294dce29ad1",
    "url": "static/js/route-deviceAdd.875c5c80.js"
  },
  {
    "revision": "689fed1e568c832cc989",
    "url": "static/js/route-deviceDetail.338b2aa2.js"
  },
  {
    "revision": "af7c5b092f32991ea4f9",
    "url": "static/js/route-index.85b58700.js"
  },
  {
    "revision": "c0ae79fcfa2f087e9fbb",
    "url": "static/js/route-login.23cdc9cc.js"
  },
  {
    "revision": "434a03c152db4eefe679",
    "url": "static/js/route-mediaDetail.024c17fb.js"
  },
  {
    "revision": "716dec28ef8d2f3f53e3",
    "url": "static/js/route-mediaList.51843d62.js"
  },
  {
    "revision": "4f5dafce39a110e16334",
    "url": "static/js/route-register.f512a2ce.js"
  },
  {
    "revision": "432cfda7fb9c9bb05ac2",
    "url": "static/js/route-server.8759a828.js"
  },
  {
    "revision": "2ffbce7d39f0d89d1073",
    "url": "static/js/route-suggest.0e8748d8.js"
  },
  {
    "revision": "dc54d771e3d5a37fcf9e",
    "url": "static/js/route-suggestAdd.86852e01.js"
  },
  {
    "revision": "4eea055d84f177c23f4e",
    "url": "static/js/route-taskList.4d2e8db0.js"
  },
  {
    "revision": "a8d067b177ee2bde87cd",
    "url": "static/js/route-user.11c9efaf.js"
  },
  {
    "revision": "40cff8e59a35326da1ed",
    "url": "static/js/route-userAgreement.c8246cd8.js"
  },
  {
    "revision": "a81086b42e927ed7dc70",
    "url": "static/js/runtime.c6b46e48.js"
  },
  {
    "revision": "52f71772361b2ea6a085",
    "url": "static/js/vendors~route-deviceDetail.89aa91e1.js"
  },
  {
    "revision": "2f682a53fb14dd6b3ba9",
    "url": "static/js/vendors~route-deviceDetail~route-mediaDetail~route-mediaList.3f78c8c9.js"
  },
  {
    "revision": "a23b65a5eecb7772dabf",
    "url": "static/js/vendors~route-mediaList.5e5c793a.js"
  },
  {
    "revision": "3cb25454b2f6c9039db1",
    "url": "static/js/vendors~route-register.9035bb88.js"
  }
]);