self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d798b6bd74caa22115c4f5dd0d8f7337",
    "url": "config.js"
  },
  {
    "revision": "fa0460ed337b8a4dc0280a9db9b322c2",
    "url": "css/pageLoading.css"
  },
  {
    "revision": "4e710d538cc8c65df49a096043728239",
    "url": "index.html"
  },
  {
    "revision": "e7b2d95bee09b90a15998827e4f62cb2",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "49886ba65189cbdbfbaf",
    "url": "static/css/app.153c725e.css"
  },
  {
    "revision": "0abbb8c767044a8cea8b",
    "url": "static/css/chunk-elementUI.caa671fd.css"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/css/chunk-libs.a7a1f4ed.css"
  },
  {
    "revision": "c70afe683886c123eef9",
    "url": "static/css/route-deviceAdd.332e44b1.css"
  },
  {
    "revision": "a21aeb8c554dcaf0ed89",
    "url": "static/css/route-deviceDetail.662deb95.css"
  },
  {
    "revision": "7673e175d9f29bc060b4",
    "url": "static/css/route-index.a73ede52.css"
  },
  {
    "revision": "0f91339576d0044b7fbd",
    "url": "static/css/route-login.0b0006f6.css"
  },
  {
    "revision": "a847548c915d1e7b22b0",
    "url": "static/css/route-mediaDetail.cbbc6f31.css"
  },
  {
    "revision": "be688eefafe8938d9647",
    "url": "static/css/route-mediaList.07252bdd.css"
  },
  {
    "revision": "b4fa079e8d742da0f7c0",
    "url": "static/css/route-register.a040e5cc.css"
  },
  {
    "revision": "8183d0710cac85c3a63f",
    "url": "static/css/route-server.6e9deedf.css"
  },
  {
    "revision": "a4a2cb6f6ed0fcc2e452",
    "url": "static/css/route-suggestAdd.99b05894.css"
  },
  {
    "revision": "ab4d2315869c2ce2da0a",
    "url": "static/css/route-taskList.cd4baab0.css"
  },
  {
    "revision": "8cfdbb8e8e882641d00a",
    "url": "static/css/route-userAgreement.772076c8.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "static/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "static/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "9865378e097d8e0c810680e2270f5bbb",
    "url": "static/fonts/iconfont.9865378e.ttf"
  },
  {
    "revision": "c66a28c69758311200c5e67531f48858",
    "url": "static/fonts/iconfont.c66a28c6.woff"
  },
  {
    "revision": "d51d021f9f72b6624cf810f492a3ed27",
    "url": "static/fonts/iconfont.d51d021f.woff2"
  },
  {
    "revision": "cce364ca9841162e3706e4f2ce0236fd",
    "url": "static/img/bg.cce364ca.webp"
  },
  {
    "revision": "6ef573dc47088fc3cb1dc910dc86a328",
    "url": "static/img/customizeScenes.6ef573dc.jpg"
  },
  {
    "revision": "f23600fbafed90f105cddbcffe2345bb",
    "url": "static/img/device.f23600fb.png"
  },
  {
    "revision": "ac85c0da7410da0a7bb5e9742491cf9e",
    "url": "static/img/empty.ac85c0da.png"
  },
  {
    "revision": "2b3728baadaf14637bc92205cfeb1f53",
    "url": "static/img/form_bg.2b3728ba.webp"
  },
  {
    "revision": "7c73e63cf036cf6aa89f9bdd2a34d8e8",
    "url": "static/img/lightScenes.7c73e63c.jpg"
  },
  {
    "revision": "bf608a126499dd90e226aa63cbc9050b",
    "url": "static/img/logo.bf608a12.png"
  },
  {
    "revision": "3809f74025db8b6a7c249e0f492597c4",
    "url": "static/img/orient.3809f740.jpg"
  },
  {
    "revision": "ec0e48cca9caf1df73018d81a3ae5c7c",
    "url": "static/img/roadScenes.ec0e48cc.jpg"
  },
  {
    "revision": "3f96a5c91876ac87ed1ef0de6691f3a6",
    "url": "static/img/weatherScenes.3f96a5c9.jpg"
  },
  {
    "revision": "49886ba65189cbdbfbaf",
    "url": "static/js/app.3eb80e64.js"
  },
  {
    "revision": "0abbb8c767044a8cea8b",
    "url": "static/js/chunk-elementUI.b8932a6a.js"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/js/chunk-libs.309eb008.js"
  },
  {
    "revision": "c70afe683886c123eef9",
    "url": "static/js/route-deviceAdd.95709c4f.js"
  },
  {
    "revision": "a21aeb8c554dcaf0ed89",
    "url": "static/js/route-deviceDetail.0e7de646.js"
  },
  {
    "revision": "7673e175d9f29bc060b4",
    "url": "static/js/route-index.beb892cb.js"
  },
  {
    "revision": "0f91339576d0044b7fbd",
    "url": "static/js/route-login.cd3b908b.js"
  },
  {
    "revision": "a847548c915d1e7b22b0",
    "url": "static/js/route-mediaDetail.aa7cf212.js"
  },
  {
    "revision": "be688eefafe8938d9647",
    "url": "static/js/route-mediaList.27f05d12.js"
  },
  {
    "revision": "b4fa079e8d742da0f7c0",
    "url": "static/js/route-register.29bba769.js"
  },
  {
    "revision": "8183d0710cac85c3a63f",
    "url": "static/js/route-server.3899599c.js"
  },
  {
    "revision": "0d7f01c0178970d9fd8a",
    "url": "static/js/route-suggest.2cb70a5d.js"
  },
  {
    "revision": "a4a2cb6f6ed0fcc2e452",
    "url": "static/js/route-suggestAdd.ad6e551c.js"
  },
  {
    "revision": "ab4d2315869c2ce2da0a",
    "url": "static/js/route-taskList.e1eecce0.js"
  },
  {
    "revision": "2ddce2414323ab23e146",
    "url": "static/js/route-user.126c5acd.js"
  },
  {
    "revision": "8cfdbb8e8e882641d00a",
    "url": "static/js/route-userAgreement.a3ae9b77.js"
  },
  {
    "revision": "d6376eb4d5e23424717e",
    "url": "static/js/runtime.e3fd3f2a.js"
  },
  {
    "revision": "310eb5526318b24f38e9",
    "url": "static/js/vendors~route-deviceDetail.f5e18d00.js"
  },
  {
    "revision": "2f682a53fb14dd6b3ba9",
    "url": "static/js/vendors~route-deviceDetail~route-mediaDetail~route-mediaList.3f78c8c9.js"
  },
  {
    "revision": "3cb25454b2f6c9039db1",
    "url": "static/js/vendors~route-register.9035bb88.js"
  }
]);