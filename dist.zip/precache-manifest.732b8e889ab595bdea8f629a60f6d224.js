self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d798b6bd74caa22115c4f5dd0d8f7337",
    "url": "config.js"
  },
  {
    "revision": "fa0460ed337b8a4dc0280a9db9b322c2",
    "url": "css/pageLoading.css"
  },
  {
    "revision": "64868a6a128fe58a7d6365a974a65c96",
    "url": "index.html"
  },
  {
    "revision": "e7b2d95bee09b90a15998827e4f62cb2",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "67d9ad7260fd5ca4c2eb",
    "url": "static/css/app.e947a5f1.css"
  },
  {
    "revision": "0abbb8c767044a8cea8b",
    "url": "static/css/chunk-elementUI.caa671fd.css"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/css/chunk-libs.a7a1f4ed.css"
  },
  {
    "revision": "efc46116aac2606434ea",
    "url": "static/css/route-deviceAdd.d88cedf4.css"
  },
  {
    "revision": "7ccd458a50d950e62787",
    "url": "static/css/route-deviceDetail.1474eb5b.css"
  },
  {
    "revision": "b8d5932b7d6595f047bc",
    "url": "static/css/route-index.b085d24d.css"
  },
  {
    "revision": "3e873bb88fdf4183c54e",
    "url": "static/css/route-login.88a4e824.css"
  },
  {
    "revision": "bbf352bbaa3c18ba0a9b",
    "url": "static/css/route-mediaDetail.cbbc6f31.css"
  },
  {
    "revision": "6a47402bda059f5443ab",
    "url": "static/css/route-mediaList.e4fdd30e.css"
  },
  {
    "revision": "21fa9349b4e6127db813",
    "url": "static/css/route-register.ce20e1f1.css"
  },
  {
    "revision": "7354b5b5c866fb9b1173",
    "url": "static/css/route-server.144f7d5f.css"
  },
  {
    "revision": "cdafb44002961338173b",
    "url": "static/css/route-suggestAdd.e76ea83d.css"
  },
  {
    "revision": "d8a56d266824e38eda6c",
    "url": "static/css/route-taskList.56d82622.css"
  },
  {
    "revision": "6d7f2217734d18798315",
    "url": "static/css/route-userAgreement.772076c8.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "static/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "static/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "9865378e097d8e0c810680e2270f5bbb",
    "url": "static/fonts/iconfont.9865378e.ttf"
  },
  {
    "revision": "c66a28c69758311200c5e67531f48858",
    "url": "static/fonts/iconfont.c66a28c6.woff"
  },
  {
    "revision": "d51d021f9f72b6624cf810f492a3ed27",
    "url": "static/fonts/iconfont.d51d021f.woff2"
  },
  {
    "revision": "cce364ca9841162e3706e4f2ce0236fd",
    "url": "static/img/bg.cce364ca.webp"
  },
  {
    "revision": "6ef573dc47088fc3cb1dc910dc86a328",
    "url": "static/img/customizeScenes.6ef573dc.jpg"
  },
  {
    "revision": "f23600fbafed90f105cddbcffe2345bb",
    "url": "static/img/device.f23600fb.png"
  },
  {
    "revision": "ac85c0da7410da0a7bb5e9742491cf9e",
    "url": "static/img/empty.ac85c0da.png"
  },
  {
    "revision": "2b3728baadaf14637bc92205cfeb1f53",
    "url": "static/img/form_bg.2b3728ba.webp"
  },
  {
    "revision": "7c73e63cf036cf6aa89f9bdd2a34d8e8",
    "url": "static/img/lightScenes.7c73e63c.jpg"
  },
  {
    "revision": "bf608a126499dd90e226aa63cbc9050b",
    "url": "static/img/logo.bf608a12.png"
  },
  {
    "revision": "3809f74025db8b6a7c249e0f492597c4",
    "url": "static/img/orient.3809f740.jpg"
  },
  {
    "revision": "ec0e48cca9caf1df73018d81a3ae5c7c",
    "url": "static/img/roadScenes.ec0e48cc.jpg"
  },
  {
    "revision": "3f96a5c91876ac87ed1ef0de6691f3a6",
    "url": "static/img/weatherScenes.3f96a5c9.jpg"
  },
  {
    "revision": "67d9ad7260fd5ca4c2eb",
    "url": "static/js/app.181f68de.js"
  },
  {
    "revision": "0abbb8c767044a8cea8b",
    "url": "static/js/chunk-elementUI.b8932a6a.js"
  },
  {
    "revision": "f05ac0072c4d93b5d08a",
    "url": "static/js/chunk-libs.309eb008.js"
  },
  {
    "revision": "efc46116aac2606434ea",
    "url": "static/js/route-deviceAdd.bda5e700.js"
  },
  {
    "revision": "7ccd458a50d950e62787",
    "url": "static/js/route-deviceDetail.8855624c.js"
  },
  {
    "revision": "b8d5932b7d6595f047bc",
    "url": "static/js/route-index.7cb1a8dc.js"
  },
  {
    "revision": "3e873bb88fdf4183c54e",
    "url": "static/js/route-login.44cfa565.js"
  },
  {
    "revision": "bbf352bbaa3c18ba0a9b",
    "url": "static/js/route-mediaDetail.2533f67c.js"
  },
  {
    "revision": "6a47402bda059f5443ab",
    "url": "static/js/route-mediaList.e91b0a1e.js"
  },
  {
    "revision": "21fa9349b4e6127db813",
    "url": "static/js/route-register.55d44ab9.js"
  },
  {
    "revision": "7354b5b5c866fb9b1173",
    "url": "static/js/route-server.e98fd1d6.js"
  },
  {
    "revision": "054fe910eff5ef7a1a99",
    "url": "static/js/route-suggest.8fb2b00f.js"
  },
  {
    "revision": "cdafb44002961338173b",
    "url": "static/js/route-suggestAdd.8d88f04f.js"
  },
  {
    "revision": "d8a56d266824e38eda6c",
    "url": "static/js/route-taskList.d1f5ceb5.js"
  },
  {
    "revision": "48d069da21b8ddb473d1",
    "url": "static/js/route-user.4ea86178.js"
  },
  {
    "revision": "6d7f2217734d18798315",
    "url": "static/js/route-userAgreement.542eafe0.js"
  },
  {
    "revision": "3c8465e49b37476ee3a6",
    "url": "static/js/runtime.a4a8f1fe.js"
  },
  {
    "revision": "310eb5526318b24f38e9",
    "url": "static/js/vendors~route-deviceDetail.f5e18d00.js"
  },
  {
    "revision": "2f682a53fb14dd6b3ba9",
    "url": "static/js/vendors~route-deviceDetail~route-mediaDetail~route-mediaList.3f78c8c9.js"
  },
  {
    "revision": "3cb25454b2f6c9039db1",
    "url": "static/js/vendors~route-register.9035bb88.js"
  }
]);